<?php

class MyPlugin extends Plugin {

    public function info() {

        $xml = simplexml_load_file(dirname(__FILE__) . '/geolocation.plugin.xml');
        return array(
            'name'        => (string)$xml->name,
            'license'     => (string)$xml->licence,
            'url'         => (string)$xml->url,
            'author'      => (string)$xml->author,
            'authorurl'   => (string)$xml->author['url'],
            'license'     => (string)$xml->license,
            'description' => (string)$xml->description,
        );

    }

    /**
     * Add the location control to the publish page
     *
     * @param FormUI $form The publish page form
     * @param Post $post The post being edited
     **/
    public function action_form_publish($form, $post) {

        if ($form->content_type->value == Post::type('entry')) {

            $location = $form->settings->append('text', 'location', 'null:null', 'Location', 'tabcontrol_text');
            $location->value = $post->info->location;
            $location->move_before($form->settings->status);
    
        }

    }

    /**
     * Handle update of the location value
     *
     * @param Post $post The post being updated
     * @param FormUI $form. The form from the publish page
     **/
    public function action_publish_post( $post, $form ) {

        if ($form->content_type->value == Post::type('entry')) {
            $post->info->location = $form->location->value;
        }

    }

    /**
     * This filter is started when the atom feed starts
     *
     * We use it to inject the georss namespace
     * 
     * @param array $namespaces 
     * @return array 
     */
    public function filter_atom_get_collection_namespaces($namespaces) {

        $namespaces['georss'] = 'http://www.georss.org/georss';
        return $namespaces;

    }

    /**
     * This action is called when an entry in the atom feed is generated
     *
     * If georss for the entry is available, we'll add it to the feed.
     * 
     * @param SimpleXMLElement $feed_entry 
     * @param Post $post 
     * @return void
     */
    public function action_atom_add_post($feed_entry, $post) {

        $location = $post->info->location;

        if(!preg_match('|^([0-9]{1,3}\.[0-9]{1,20})(?:[\s]*),(?:[\s]*)([0-9]{1,3}\.[0-9]{1,20})$|',$location,$matches)) return;
        
        if ($location) {
            $feed_entry->addChild('point',$matches[1] . ' ' . $matches[2], 'http://www.georss.org/georss');
        }

    }
}

?>
